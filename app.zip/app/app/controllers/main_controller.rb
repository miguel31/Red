class MainController < ApplicationController
  def home
  end
end
